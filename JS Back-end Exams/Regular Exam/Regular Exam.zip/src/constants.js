const PORT = 3000;
const CONN_STR = "mongodb://127.0.0.1:27017/";
const DB_NAME = "regular-exam-db";
const SECRET = "djcbd44dhj45cbdhsjbsjbsds56dc4dc4dcdc";

module.exports = {
    PORT,
    CONN_STR,
    DB_NAME,
    SECRET
};