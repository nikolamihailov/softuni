const registerPage = document.getElementById("registerPage");

export function showRegister(ctx) {
    ctx.showSection(registerPage);
}