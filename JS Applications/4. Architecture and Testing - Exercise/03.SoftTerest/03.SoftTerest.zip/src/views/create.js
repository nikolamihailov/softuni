const createPage = document.getElementById("createPage");

export function showCreate(ctx) {
    ctx.showSection(createPage);
}