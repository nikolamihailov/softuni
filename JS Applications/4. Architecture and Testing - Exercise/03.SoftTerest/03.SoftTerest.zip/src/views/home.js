const homePage = document.getElementById("homePage");

export function showHome(ctx) {
    ctx.showSection(homePage);
}