const loginPage = document.getElementById("loginPage");

export function showLogin(ctx) {
    ctx.showSection(loginPage);
}