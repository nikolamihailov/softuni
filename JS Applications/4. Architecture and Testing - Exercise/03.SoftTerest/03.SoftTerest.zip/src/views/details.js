const detailsPage = document.getElementById("detailsPage");

export function showDetails(ctx) {
    ctx.showSection(detailsPage);
}